#ifndef APPENDER_HH
#define APPENDER_HH

namespace log4cpp {

  class Appender
  {
  public:
    virtual ~Appender();

  };
}

#endif // APPENDER_HH
