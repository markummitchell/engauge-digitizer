#ifndef CONVENIENCE_H
#define CONVENIENCE_H

#define LOG4CPP_EMERG_S(logger) \
  if (false) logger.nullStream()
#define LOG4CPP_FATAL_S(logger) \
  if (false) logger.nullStream()
#define LOG4CPP_ALERT_S(logger) \
  if (false) logger.nullStream()
#define LOG4CPP_CRIT_S(logger) \
  if (false) logger.nullStream()
#define LOG4CPP_ERROR_S(logger) \
  if (false) logger.nullStream()
#define LOG4CPP_WARN_S(logger) \
  if (false) logger.nullStream()
#define LOG4CPP_NOTICE_S(logger) \
  if (false) logger.nullStream()
#define LOG4CPP_INFO_S(logger) \
  if (false) logger.nullStream()
#define LOG4CPP_DEBUG_S(logger) \
  if (false) logger.nullStream()

#endif // CONVENIENCE_H
